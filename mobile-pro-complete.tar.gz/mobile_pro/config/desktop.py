from frappe import _

def get_data():
    return [
        {
            "module_name": "Mobile Pro",
            "color": "#3498db",
            "icon": "octicon octicon-device-mobile",
            "type": "module",
            "label": _("Mobile Pro")
        }
    ]